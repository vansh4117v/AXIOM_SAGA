# SAGE — Situational Awareness & Guidance Engine
## Complete Project Specification v1.0
### Veersa Hackathon 2027 | Team Submission Document

---

## 0. What This System Actually Is

SAGE is a Jira-integrated multi-agent AI system that intercepts tickets at creation via polling, builds a **Situational Briefing** by reasoning across live codebase context, team knowledge graphs, and historical risk signals — then delivers that intelligence as a structured comment back into the Jira ticket and on a live React dashboard.

**It does not process tickets. It reasons about them.**

The core claim: two tickets that look superficially similar will produce different agent execution paths, different tool call sequences, and different outputs — because the Orchestrator reads ticket signals and builds a runtime plan, not a fixed pipeline. This branching is visible, traceable, and explainable.

**One-line pitch:** SAGE turns the 3-hour "who do I ask and what do I do" delay that every junior engineer faces into a 30-second briefing delivered where they already work — inside Jira.

---

## 1. Problem Statement

A Jira ticket assigned to a junior engineer contains 3 sentences. Behind those 3 sentences is:
- Relevant codebase context and recent changes
- Previous architectural decisions that caused this design
- The right person to pair with and what specifically to ask them
- Historical bugs in the same module
- Unspoken team conventions that seniors know and juniors don't

The junior either spends 2-3 hours figuring this out alone, or interrupts a senior who loses context and momentum. Both outcomes are expensive. Existing tools (Jira automation, Linear AI) solve *routing*. They do not solve *understanding*.

**The cost is not the ticket. The cost is the frozen engineer.**

---

## 2. System Overview

```
Jira Cloud (polling every 60s)
    → Node.js Gateway (normalise → TicketDTO → deduplicate)
        → FastAPI AI Engine (LangGraph orchestration)
            → Orchestrator Agent (classify + build runtime plan)
                → Context Agent    (pgvector + GitHub API)
                → Routing Agent    (team registry JSON)
                → Explainer Agent  (plain language + steps)
                → Risk Agent       (open bugs + history)
            → Synthesis (assemble briefing + ask-senior message)
        → Azure PostgreSQL (persist briefing + trace)
        → Jira API (write structured comment back to ticket)
    → React Dashboard (live SSE stream of agent events)
```

---

## 3. Repository Structure

```
sage/
├── frontend/                          # React + Tailwind (Person A)
│   ├── src/
│   │   ├── components/
│   │   │   ├── TicketQueue.jsx        # list of polled tickets
│   │   │   ├── BriefingPanel.jsx      # 5-section briefing display
│   │   │   ├── AgentTrace.jsx         # live execution timeline
│   │   │   ├── PromptStudio.jsx       # editable prompts per agent
│   │   │   ├── ConfidenceBadge.jsx    # computed confidence display
│   │   │   └── CompareView.jsx        # side-by-side 2-ticket diff
│   │   ├── hooks/
│   │   │   └── useSSE.js              # SSE connection + event parsing
│   │   ├── api/
│   │   │   └── client.js              # axios wrapper for Node gateway
│   │   └── App.jsx
│   ├── .env.example
│   └── package.json
│
├── gateway/                           # Node.js (Person B)
│   ├── src/
│   │   ├── routes/
│   │   │   ├── tickets.js             # manual submission endpoint
│   │   │   ├── auth.js                # JWT login/verify
│   │   │   └── prompts.js             # CRUD for agent prompts
│   │   ├── services/
│   │   │   ├── jiraPoller.js          # polls Jira every 60s
│   │   │   ├── jiraNormaliser.js      # Jira issue → TicketDTO
│   │   │   ├── deduplicator.js        # prevent double processing
│   │   │   └── jiraWriter.js          # POST comment back to Jira
│   │   ├── middleware/
│   │   │   └── auth.js                # JWT middleware
│   │   └── index.js
│   ├── .env.example
│   └── package.json
│
├── ai_engine/                         # FastAPI + LangGraph (Person C)
│   ├── agents/
│   │   ├── orchestrator.py            # LangGraph graph definition
│   │   ├── context_agent.py           # pgvector + GitHub tools
│   │   ├── routing_agent.py           # team registry matching
│   │   ├── explainer_agent.py         # plain language generation
│   │   ├── risk_agent.py              # bug history + flags
│   │   └── synthesis.py              # assemble final briefing
│   ├── tools/
│   │   ├── github_tools.py            # GitHub API wrappers
│   │   ├── vector_tools.py            # pgvector search
│   │   └── registry_tools.py          # team registry lookup
│   ├── models/
│   │   ├── scratchpad.py              # TypedDict state schema
│   │   └── briefing.py                # output schema
│   ├── api/
│   │   └── routes.py                  # /analyse + /stream endpoints
│   ├── db/
│   │   ├── connection.py
│   │   ├── embeddings.py              # embed + store codebase
│   │   └── migrations/
│   │       └── 001_init.sql
│   ├── config/
│   │   └── prompts.json               # all agent system prompts (REQUIRED by PDF)
│   ├── tests/
│   │   ├── test_orchestrator.py       # unit tests
│   │   ├── test_context_agent.py
│   │   └── sage_api.postman_collection.json  # API tests
│   ├── .env.example
│   └── requirements.txt
│
├── .github/
│   └── workflows/
│       └── deploy.yml                 # CI/CD pipeline
├── docker-compose.yml
├── architecture.png                   # export from this spec
└── README.md
```

---

## 4. The Scratchpad — Single Source of Truth

**Define this before writing any agent code. Every agent reads and writes only its designated fields.**

```python
# ai_engine/models/scratchpad.py
from typing import TypedDict, Optional

class AgentScratchpad(TypedDict):
    # ── Input (set by gateway, never mutated) ──────────────────────
    ticket_id: str           # e.g. "PROJ-347"
    ticket_key: str          # Jira issue key
    ticket_summary: str      # one-line title
    ticket_description: str  # full body
    ticket_priority: str     # "High" | "Medium" | "Low" | "Critical"
    ticket_labels: list      # ["payments", "production"]
    ticket_components: list  # ["Backend API"]
    ticket_assignee: dict    # {name, email, jira_account_id}
    ticket_reporter: dict
    ticket_created: str      # ISO timestamp
    ticket_type: str         # "Bug" | "Story" | "Task"

    # ── Orchestrator writes (first node) ──────────────────────────
    classification: dict
    execution_plan: list
    plan_reasoning: str

    # ── Context Agent writes ───────────────────────────────────────
    relevant_files: list
    related_prs: list
    related_tickets: list
    context_confidence: float
    context_retry_count: int

    # ── Routing Agent writes ───────────────────────────────────────
    primary_owner: dict
    escalation_path: list
    routing_confidence: float
    suggested_question: str

    # ── Explainer Agent writes ────────────────────────────────────
    plain_summary: str
    suggested_steps: list
    audience_level: str
    key_concepts: list

    # ── Risk Agent writes ──────────────────────────────────────────
    risk_flags: list
    open_related_bugs: list
    historical_incidents: list
    overall_risk_level: str

    # ── Synthesis writes (final node) ────────────────────────────
    briefing: dict
    ask_senior_message: str
    jira_comment_body: str
    overall_confidence: float

    # ── System fields ────────────────────────────────────────────
    agent_trace: list
    sse_events: list
    run_id: str
    processing_status: str
    error: Optional[str]
```

---

## 5. LangGraph Orchestrator — The Branching Logic

```python
# ai_engine/agents/orchestrator.py
from langgraph.graph import StateGraph, END
from models.scratchpad import AgentScratchpad

def classify_and_plan(state: AgentScratchpad) -> AgentScratchpad:
    classification = call_llm_classify(state)
    plan = []

    if classification["severity"] == "P0" or classification["is_production"]:
        plan = ["risk", "context", "routing"]
        reasoning = "P0/production ticket — risk assessment prioritised, explainer skipped for urgency"
    elif classification["estimated_complexity"] == "low":
        plan = ["context", "routing", "explainer"]
        reasoning = "Low complexity ticket — risk agent skipped, standard flow"
    else:
        plan = ["context", "routing", "explainer", "risk"]
        reasoning = "Standard ticket — full analysis pipeline"

    state["classification"] = classification
    state["execution_plan"] = plan
    state["plan_reasoning"] = reasoning
    state["agent_trace"].append({
        "agent": "orchestrator",
        "decision_made": f"plan: {plan}",
        "reasoning": reasoning
    })
    return state


def should_run_risk_first(state: AgentScratchpad) -> str:
    if state["execution_plan"][0] == "risk":
        return "risk_agent"
    return "context_agent"


def should_retry_context(state: AgentScratchpad) -> str:
    if state["context_confidence"] < 0.60 and state["context_retry_count"] < 2:
        return "context_agent"
    return "routing_agent"


def should_run_explainer(state: AgentScratchpad) -> str:
    if "explainer" not in state["execution_plan"]:
        return "synthesis"
    return "explainer_agent"


def build_sage_graph():
    graph = StateGraph(AgentScratchpad)

    graph.add_node("orchestrator", classify_and_plan)
    graph.add_node("context_agent", run_context_agent)
    graph.add_node("routing_agent", run_routing_agent)
    graph.add_node("explainer_agent", run_explainer_agent)
    graph.add_node("risk_agent", run_risk_agent)
    graph.add_node("synthesis", run_synthesis)

    graph.set_entry_point("orchestrator")

    graph.add_conditional_edges(
        "orchestrator",
        should_run_risk_first,
        {"risk_agent": "risk_agent", "context_agent": "context_agent"}
    )
    graph.add_conditional_edges(
        "context_agent",
        should_retry_context,
        {"context_agent": "context_agent", "routing_agent": "routing_agent"}
    )
    graph.add_edge("risk_agent", "context_agent")
    graph.add_edge("routing_agent", "explainer_agent_check")
    graph.add_conditional_edges(
        "explainer_agent_check",
        should_run_explainer,
        {"explainer_agent": "explainer_agent", "synthesis": "synthesis"}
    )
    graph.add_edge("explainer_agent", "synthesis")
    graph.add_edge("synthesis", END)

    return graph.compile()
```

---

## 6. Context Agent — Real Tool Use

```python
# ai_engine/agents/context_agent.py

TOOLS = [
    {
        "name": "search_codebase",
        "description": "Semantic search over embedded codebase files.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "top_k": {"type": "integer", "default": 5}
            }
        }
    },
    {
        "name": "get_file_content",
        "description": "Get actual content of a specific file from GitHub.",
        "input_schema": {
            "type": "object",
            "properties": {"file_path": {"type": "string"}}
        }
    },
    {
        "name": "get_recent_prs_for_file",
        "description": "Get recent PRs that touched a specific file path.",
        "input_schema": {
            "type": "object",
            "properties": {
                "file_path": {"type": "string"},
                "limit": {"type": "integer", "default": 5}
            }
        }
    },
    {
        "name": "search_closed_tickets",
        "description": "Search closed Jira tickets similar to the current one.",
        "input_schema": {
            "type": "object",
            "properties": {"keywords": {"type": "array", "items": {"type": "string"}}}
        }
    }
]

def run_context_agent(state: AgentScratchpad) -> AgentScratchpad:
    messages = [{"role": "user", "content": build_context_prompt(state)}]
    tools_called = []

    while True:
        response = anthropic_client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=2000,
            system=load_prompt("context_agent"),
            tools=TOOLS,
            messages=messages
        )

        if response.stop_reason == "end_turn":
            break

        if response.stop_reason == "tool_use":
            tool_results = []
            for block in response.content:
                if block.type == "tool_use":
                    result = execute_tool(block.name, block.input, state)
                    if block.name == "search_codebase":
                        result = validate_file_paths(result)
                    tools_called.append({
                        "tool": block.name,
                        "input": block.input,
                        "result_count": len(result) if isinstance(result, list) else 1
                    })
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": str(result)
                    })
            messages.append({"role": "assistant", "content": response.content})
            messages.append({"role": "user", "content": tool_results})

    parsed = parse_context_output(response)
    confidence = compute_retrieval_confidence(parsed["relevant_files"])

    state["relevant_files"] = parsed["relevant_files"]
    state["related_prs"] = parsed["related_prs"]
    state["related_tickets"] = parsed["related_tickets"]
    state["context_confidence"] = confidence
    state["context_retry_count"] = state.get("context_retry_count", 0) + 1

    state["agent_trace"].append({
        "agent": "context_agent",
        "tools_called": tools_called,
        "confidence": confidence,
        "decision_made": f"found {len(parsed['relevant_files'])} relevant files",
        "reasoning": f"confidence={confidence:.2f}, retry={state['context_retry_count']}"
    })
    return state


def compute_retrieval_confidence(files: list) -> float:
    if not files:
        return 0.0
    scores = [f.get("similarity_score", 0) for f in files]
    return round(sum(scores) / len(scores), 2)
```

---

## 7. Codebase Embedding — Setup Script

```python
# ai_engine/db/embeddings.py
import anthropic, psycopg2, requests, os, base64
from pathlib import Path

SUPPORTED_EXTENSIONS = ['.py', '.js', '.ts', '.jsx', '.tsx', '.java', '.go']

def embed_repository(owner: str, repo: str, branch: str = "main"):
    github_token = os.getenv("GITHUB_TOKEN")
    headers = {"Authorization": f"token {github_token}"}

    tree_url = f"https://api.github.com/repos/{owner}/{repo}/git/trees/{branch}?recursive=1"
    tree = requests.get(tree_url, headers=headers).json()

    client = anthropic.Anthropic()
    conn = get_db_connection()

    for item in tree["tree"]:
        if item["type"] != "blob":
            continue
        if Path(item["path"]).suffix not in SUPPORTED_EXTENSIONS:
            continue

        content_url = f"https://api.github.com/repos/{owner}/{repo}/contents/{item['path']}"
        content_resp = requests.get(content_url, headers=headers).json()
        raw = base64.b64decode(content_resp["content"]).decode("utf-8", errors="ignore")

        chunk = extract_semantic_chunk(raw, Path(item["path"]).suffix)
        if not chunk.strip():
            continue

        embedding_resp = client.embeddings.create(model="voyage-code-2", input=[chunk])
        embedding = embedding_resp.embeddings[0].embedding

        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO code_embeddings (repo, file_path, chunk_text, embedding, last_updated)
                VALUES (%s, %s, %s, %s, NOW())
                ON CONFLICT (repo, file_path) DO UPDATE
                SET chunk_text = EXCLUDED.chunk_text,
                    embedding = EXCLUDED.embedding,
                    last_updated = NOW()
            """, (f"{owner}/{repo}", item["path"], chunk, embedding))
        conn.commit()

    print(f"Embedded {owner}/{repo} successfully")


def search_codebase(query: str, top_k: int = 5) -> list:
    client = anthropic.Anthropic()
    query_embedding = client.embeddings.create(
        model="voyage-code-2", input=[query]
    ).embeddings[0].embedding

    conn = get_db_connection()
    with conn.cursor() as cur:
        cur.execute("""
            SELECT file_path, chunk_text,
                   1 - (embedding <=> %s::vector) AS similarity
            FROM code_embeddings
            ORDER BY embedding <=> %s::vector
            LIMIT %s
        """, (query_embedding, query_embedding, top_k))

        return [
            {"path": row[0], "snippet": row[1][:500], "similarity_score": round(float(row[2]), 3)}
            for row in cur.fetchall()
        ]
```

---

## 8. Database Schema

```sql
-- ai_engine/db/migrations/001_init.sql

CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE code_embeddings (
    id           SERIAL PRIMARY KEY,
    repo         VARCHAR(255) NOT NULL,
    file_path    VARCHAR(512) NOT NULL,
    chunk_text   TEXT NOT NULL,
    embedding    vector(1024),
    last_updated TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(repo, file_path)
);
CREATE INDEX ON code_embeddings USING ivfflat (embedding vector_cosine_ops);

CREATE TABLE tickets (
    id            SERIAL PRIMARY KEY,
    ticket_key    VARCHAR(50) UNIQUE NOT NULL,
    jira_issue_id VARCHAR(50) UNIQUE NOT NULL,
    raw_payload   JSONB NOT NULL,
    ticket_dto    JSONB NOT NULL,
    status        VARCHAR(50) DEFAULT 'pending',
    received_at   TIMESTAMPTZ DEFAULT NOW(),
    processed_at  TIMESTAMPTZ
);

CREATE TABLE briefings (
    id                 SERIAL PRIMARY KEY,
    run_id             UUID DEFAULT gen_random_uuid(),
    ticket_key         VARCHAR(50) REFERENCES tickets(ticket_key),
    scratchpad         JSONB NOT NULL,
    briefing           JSONB NOT NULL,
    agent_trace        JSONB NOT NULL,
    overall_confidence FLOAT,
    execution_plan     TEXT[],
    created_at         TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE agent_prompts (
    id           SERIAL PRIMARY KEY,
    agent_name   VARCHAR(100) UNIQUE NOT NULL,
    system_prompt TEXT NOT NULL,
    version      INT DEFAULT 1,
    updated_at   TIMESTAMPTZ DEFAULT NOW(),
    updated_by   VARCHAR(100)
);

CREATE TABLE team_registry (
    id                  SERIAL PRIMARY KEY,
    team_name           VARCHAR(100) NOT NULL,
    member_name         VARCHAR(100) NOT NULL,
    role                VARCHAR(100),
    github_handle       VARCHAR(100),
    domains             TEXT[],
    owned_paths         TEXT[],
    escalation_priority INT DEFAULT 1
);

CREATE TABLE jira_poll_state (
    id             SERIAL PRIMARY KEY,
    last_polled_at TIMESTAMPTZ DEFAULT NOW(),
    last_ticket_key VARCHAR(50)
);
```

---

## 9. Jira Polling Service

```javascript
// gateway/src/services/jiraPoller.js
const axios = require('axios');
const cron = require('node-cron');

const JIRA_BASE_URL = process.env.JIRA_BASE_URL;
const JIRA_EMAIL = process.env.JIRA_EMAIL;
const JIRA_API_TOKEN = process.env.JIRA_API_TOKEN;
const JIRA_PROJECT_KEY = process.env.JIRA_PROJECT_KEY;
const jiraAuth = { auth: { username: JIRA_EMAIL, password: JIRA_API_TOKEN } };

const processedTickets = new Set();

async function pollJira() {
    try {
        const jql = `project = ${JIRA_PROJECT_KEY} AND updated >= -2m ORDER BY updated DESC`;
        const response = await axios.get(`${JIRA_BASE_URL}/rest/api/3/search`, {
            params: {
                jql,
                maxResults: 20,
                fields: 'summary,description,priority,assignee,reporter,labels,components,status,issuetype,created,updated,comment'
            },
            ...jiraAuth
        });

        for (const issue of response.data.issues) {
            const key = issue.key;
            if (processedTickets.has(key)) continue;
            const alreadyProcessed = await checkDB(key);
            if (alreadyProcessed) continue;

            console.log(`[Jira Poll] New ticket: ${key}`);
            const dto = normaliseToTicketDTO(issue);
            await forwardToAIEngine(dto);
            processedTickets.add(key);
        }
    } catch (err) {
        console.error('[Jira Poll] Error:', err.message);
    }
}

function normaliseToTicketDTO(issue) {
    return {
        ticket_id: issue.id,
        ticket_key: issue.key,
        ticket_summary: issue.fields.summary,
        ticket_description: extractPlainText(issue.fields.description),
        ticket_priority: issue.fields.priority?.name || 'Medium',
        ticket_labels: issue.fields.labels || [],
        ticket_components: issue.fields.components?.map(c => c.name) || [],
        ticket_assignee: {
            name: issue.fields.assignee?.displayName || 'Unassigned',
            email: issue.fields.assignee?.emailAddress || null,
            jira_account_id: issue.fields.assignee?.accountId || null
        },
        ticket_reporter: {
            name: issue.fields.reporter?.displayName,
            email: issue.fields.reporter?.emailAddress
        },
        ticket_created: issue.fields.created,
        ticket_type: issue.fields.issuetype?.name || 'Task'
    };
}

async function forwardToAIEngine(dto) {
    await axios.post(`${process.env.AI_ENGINE_URL}/analyse`, dto);
}

cron.schedule('*/1 * * * *', pollJira);
module.exports = { pollJira };
```

---

## 10. Jira Write-Back Service

```javascript
// gateway/src/services/jiraWriter.js

async function writeCommentToJira(ticketKey, briefing, traceUrl) {
    const commentBody = {
        body: {
            type: "doc",
            version: 1,
            content: [
                {
                    type: "heading",
                    attrs: { level: 3 },
                    content: [{ type: "text", text: `🤖 SAGE Analysis — confidence ${Math.round(briefing.overall_confidence * 100)}%` }]
                },
                {
                    type: "paragraph",
                    content: [
                        { type: "text", marks: [{ type: "strong" }], text: "Context: " },
                        { type: "text", text: briefing.context_summary }
                    ]
                },
                {
                    type: "paragraph",
                    content: [
                        { type: "text", marks: [{ type: "strong" }], text: "Suggested owner: " },
                        { type: "text", text: `${briefing.primary_owner.name} (${briefing.primary_owner.team})` }
                    ]
                },
                {
                    type: "paragraph",
                    content: [
                        { type: "text", marks: [{ type: "strong" }], text: "Risk level: " },
                        { type: "text", text: briefing.overall_risk_level },
                        ...(briefing.risk_flags.length > 0 ? [
                            { type: "text", text: ` — ${briefing.risk_flags[0].flag}` }
                        ] : [])
                    ]
                },
                {
                    type: "blockquote",
                    content: [{
                        type: "paragraph",
                        content: [
                            { type: "text", marks: [{ type: "strong" }], text: "Suggested question to send: " },
                            { type: "hardBreak" },
                            { type: "text", text: briefing.suggested_question }
                        ]
                    }]
                },
                {
                    type: "paragraph",
                    content: [{
                        type: "text",
                        marks: [{ type: "link", attrs: { href: traceUrl } }],
                        text: "→ View full briefing and agent trace in SAGE"
                    }]
                }
            ]
        }
    };

    await axios.post(
        `${JIRA_BASE_URL}/rest/api/3/issue/${ticketKey}/comment`,
        commentBody,
        jiraAuth
    );
}

module.exports = { writeCommentToJira };
```

---

## 11. SSE Streaming — Real-Time Agent Events

```python
# ai_engine/api/routes.py
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
import asyncio, json
from uuid import uuid4

app = FastAPI()

@app.post("/analyse")
async def analyse_ticket(ticket_dto: dict):
    run_id = str(uuid4())
    await db.save_ticket(ticket_dto, run_id)
    asyncio.create_task(run_pipeline(ticket_dto, run_id))
    return {"run_id": run_id, "status": "processing"}


@app.get("/stream/{run_id}")
async def stream_events(run_id: str):
    async def event_generator():
        while True:
            events = await db.get_new_sse_events(run_id)
            for event in events:
                yield f"data: {json.dumps(event)}\n\n"

            status = await db.get_run_status(run_id)
            if status in ["complete", "failed"]:
                yield f"data: {json.dumps({'type': 'done', 'status': status})}\n\n"
                break

            await asyncio.sleep(0.5)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"}
    )

# SSE event types pushed during pipeline:
# {type: "plan_ready",     data: {plan, reasoning}}
# {type: "agent_started",  data: {agent, tools_available}}
# {type: "tool_called",    data: {agent, tool, input_summary}}
# {type: "tool_result",    data: {agent, tool, result_summary, confidence}}
# {type: "agent_complete", data: {agent, duration_ms, confidence, decision}}
# {type: "briefing_ready", data: {briefing, trace, run_id}}
# {type: "jira_commented", data: {ticket_key, comment_url}}
```

---

## 12. Prompts Config — Required by PDF

```json
{
  "orchestrator": {
    "version": 1,
    "system_prompt": "You are the Orchestrator for SAGE, a multi-agent ticket analysis system. Your job is to classify a Jira ticket and build an execution plan for the other agents.\n\nClassify the ticket into:\n- severity: P0 (production down/data loss risk), P1 (major feature broken), P2 (non-critical)\n- domain: the engineering domain (payments, frontend, infra, auth, data, etc.)\n- is_production: true if labels or description mention prod/production/live\n- has_clear_assignee: true if a specific engineer is assigned\n- estimated_complexity: low (docs/minor bug), medium (feature/bug), high (architectural/system)\n\nAlways explain your reasoning for each classification.\n\nReturn JSON only:\n{\"severity\": \"P0|P1|P2\", \"domain\": \"string\", \"is_production\": bool, \"has_clear_assignee\": bool, \"estimated_complexity\": \"low|medium|high\", \"reasoning\": \"string\"}"
  },
  "context_agent": {
    "version": 1,
    "system_prompt": "You are the Context Agent for SAGE. Your job is to find what parts of the codebase are relevant to this Jira ticket.\n\nYou have access to these tools:\n- search_codebase(query): semantic search over embedded code files\n- get_file_content(file_path): fetch actual file content from GitHub\n- get_recent_prs_for_file(file_path): find recent PRs touching a file\n- search_closed_tickets(keywords): find similar resolved tickets\n\nStrategy:\n1. Extract key technical concepts from the ticket\n2. Search codebase with those concepts\n3. For the top results, fetch actual file content to verify relevance\n4. Find recent PRs on relevant files to identify who knows this code\n5. Search for similar past tickets\n\nOnly cite files you have actually retrieved. Never invent file paths.\nStop when you have 3-5 high-confidence relevant files or have tried 3 different queries."
  },
  "routing_agent": {
    "version": 1,
    "system_prompt": "You are the Routing Agent for SAGE. Given a ticket and the codebase context already found, identify the best person to own or assist with this ticket.\n\nUse the team registry tool to find who owns the relevant files and domains.\n\nYour output must include:\n1. primary_owner: the best person, with reason (cite specific files they own)\n2. escalation_path: 1-2 backup contacts if primary is unavailable\n3. suggested_question: a complete, specific, ready-to-send message the junior can copy and send. The message must reference specific file names and PR numbers from the context. It must not be generic.\n\nExample of a BAD suggested question: 'Hey, can you help me with this ticket?'\nExample of a GOOD suggested question: 'Hey Priya, I picked up PROJ-347 about the payment retry failure. SAGE found that payments/processor.py was last touched in PR #234 which you merged. Before I start, was the MAX_RETRIES=3 constant intentional or a temporary fix? The ticket suggests it might be causing the timeout cascade.'"
  },
  "explainer_agent": {
    "version": 1,
    "system_prompt": "You are the Explainer Agent for SAGE. Your audience is a junior engineer or intern who may not know the full codebase.\n\nGiven the ticket and context already found, produce:\n1. plain_summary: what this ticket is actually asking for, in plain English, 2-3 sentences\n2. suggested_steps: 3-6 concrete steps to approach this ticket. Each step must have: the action, why it makes sense given the context found, and an estimated effort in hours.\n3. key_concepts: list any technical concepts mentioned that a junior might not know — just name them, don't explain them here.\n\nTone: clear, direct, non-condescending. Assume the junior is capable but new to this codebase."
  },
  "risk_agent": {
    "version": 1,
    "system_prompt": "You are the Risk Agent for SAGE. Your job is to identify risks in the current ticket based on context.\n\nLook for:\n- Are there open bugs in the same files or module?\n- Has this area caused incidents before (check related tickets)?\n- Is this a high-traffic code path?\n- Does the ticket touch auth, payments, or data integrity?\n- Are there dependencies that could break?\n\nFor each risk flag, provide: the flag description, severity (critical/high/medium), and specific evidence (cite ticket keys or file names).\n\nOverall risk level: critical if any flag is critical, high if any is high, medium otherwise.\n\nDo not invent risks without evidence from the context provided."
  },
  "synthesis": {
    "version": 1,
    "system_prompt": "You are the Synthesis node for SAGE. You have the complete scratchpad from all agents. Assemble the final briefing.\n\nThe briefing must be structured as:\n- context_summary: 1-2 sentences on what files/context was found\n- owner_summary: who owns this and why\n- steps_summary: the suggested approach\n- risk_summary: key risks in one sentence\n- ask_senior_message: the complete suggested question from Routing Agent (copy exactly)\n\nAlso generate jira_comment_body: a clean markdown-formatted version for posting as a Jira comment. Keep it under 200 words. Lead with confidence score. Include the ask-senior question as a blockquote."
  }
}
```

---

## 13. Environment Variables

```bash
# ai_engine/.env.example
ANTHROPIC_API_KEY=
AZURE_POSTGRES_URL=postgresql://user:pass@host:5432/sage
GITHUB_TOKEN=
GITHUB_OWNER=
GITHUB_REPOS=repo1,repo2
AI_ENGINE_PORT=8000

# gateway/.env.example
JIRA_BASE_URL=https://yourteam.atlassian.net
JIRA_EMAIL=
JIRA_API_TOKEN=
JIRA_PROJECT_KEY=PROJ
AI_ENGINE_URL=http://localhost:8000
JWT_SECRET=
GATEWAY_PORT=3001

# frontend/.env.example
VITE_GATEWAY_URL=http://localhost:3001
VITE_AI_ENGINE_URL=http://localhost:8000
```

---

## 14. GitHub Actions CI/CD

```yaml
# .github/workflows/deploy.yml
name: SAGE CI/CD

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3

      - name: Set up Python
        uses: actions/setup-python@v4
        with: { python-version: '3.11' }

      - name: Install AI engine deps
        run: pip install -r ai_engine/requirements.txt

      - name: Run unit tests
        run: pytest ai_engine/tests/ -v --tb=short
        env:
          ANTHROPIC_API_KEY: ${{ secrets.ANTHROPIC_API_KEY }}
          AZURE_POSTGRES_URL: ${{ secrets.AZURE_POSTGRES_URL }}

      - name: Set up Node
        uses: actions/setup-node@v3
        with: { node-version: '20' }

      - name: Install gateway deps
        run: cd gateway && npm ci

      - name: Run API tests
        run: |
          cd gateway && npm start &
          sleep 5
          cd ai_engine && uvicorn api.routes:app --port 8000 &
          sleep 5
          npx newman run ai_engine/tests/sage_api.postman_collection.json \
            --env-var "base_url=http://localhost:8000"

  build-and-deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
      - uses: actions/checkout@v3

      - name: Log in to Azure Container Registry
        uses: azure/docker-login@v1
        with:
          login-server: ${{ secrets.ACR_LOGIN_SERVER }}
          username: ${{ secrets.ACR_USERNAME }}
          password: ${{ secrets.ACR_PASSWORD }}

      - name: Build and push AI engine image
        run: |
          docker build -t ${{ secrets.ACR_LOGIN_SERVER }}/sage-ai:${{ github.sha }} ./ai_engine
          docker push ${{ secrets.ACR_LOGIN_SERVER }}/sage-ai:${{ github.sha }}

      - name: Build and push Gateway image
        run: |
          docker build -t ${{ secrets.ACR_LOGIN_SERVER }}/sage-gateway:${{ github.sha }} ./gateway
          docker push ${{ secrets.ACR_LOGIN_SERVER }}/sage-gateway:${{ github.sha }}

      - name: Deploy AI engine to Azure
        uses: azure/webapps-deploy@v2
        with:
          app-name: sage-ai-engine
          images: ${{ secrets.ACR_LOGIN_SERVER }}/sage-ai:${{ github.sha }}

      - name: Deploy Gateway to Azure
        uses: azure/webapps-deploy@v2
        with:
          app-name: sage-gateway
          images: ${{ secrets.ACR_LOGIN_SERVER }}/sage-gateway:${{ github.sha }}

      - name: Deploy Frontend to Azure Static Web Apps
        uses: Azure/static-web-apps-deploy@v1
        with:
          azure_static_web_apps_api_token: ${{ secrets.AZURE_STATIC_WEB_APPS_TOKEN }}
          repo_token: ${{ secrets.GITHUB_TOKEN }}
          action: "upload"
          app_location: "/frontend"
          output_location: "dist"
```

---

## 15. Team Work Division

### Person A — Frontend (React + Tailwind)
**Day 1 priorities in order:**
1. Scaffold React app with Tailwind, basic layout: left panel (ticket queue) + right panel (briefing)
2. Build `useSSE.js` hook — connect to `/stream/{run_id}`, parse event types, update state
3. Build `AgentTrace.jsx` — timeline showing each agent as it completes, with duration and confidence
4. Build `BriefingPanel.jsx` — 5 sections: Context / Owner / Steps / Risks / Ask-Senior (with copy button)
5. Build `ConfidenceBadge.jsx` — colour-coded: green >75%, amber 50-75%, red <50%
6. Build `PromptStudio.jsx` — fetch prompts from gateway, render textarea per agent, save button
7. Build `CompareView.jsx` — side-by-side two ticket traces, highlight where execution paths diverge

**Key constraint:** All API calls go to Node.js gateway (port 3001). SSE connects directly to FastAPI (port 8000).

---

### Person B — Node.js Gateway
**Day 1 priorities in order:**
1. Set up Express app, JWT middleware, basic auth
2. Build `jiraNormaliser.js` — convert raw Jira issue JSON to TicketDTO
3. Build `jiraPoller.js` — cron every 60s, fetch new tickets, deduplicate, forward to FastAPI
4. Build `jiraWriter.js` — POST ADF-formatted comment back to Jira after briefing complete
5. Build routes: `POST /tickets`, `GET /tickets`, `GET /prompts`, `PUT /prompts/:agent`
6. Build `deduplicator.js` — check DB before forwarding
7. Connect to Azure PostgreSQL for ticket storage and prompt CRUD

**Key constraint:** The gateway never calls the LLM directly.

---

### Person C — FastAPI + LangGraph AI Engine
**Day 1 priorities in order:**
1. Set up FastAPI app, DB connection, run `001_init.sql` migration
2. Define `AgentScratchpad` TypedDict in full — this is the contract everything else builds on
3. Build and run `embed_repository()` — embed your GitHub repos into pgvector RIGHT NOW
4. Build `context_agent.py` with real tool use loop
5. Build `orchestrator.py` with LangGraph — nodes, conditional edges, entry point
6. Build `routing_agent.py`, `explainer_agent.py`, `risk_agent.py`, `synthesis.py`
7. Build `/analyse` and `/stream/{run_id}` FastAPI endpoints
8. Wire SSE events — push event to DB queue at each agent step

**Key constraint:** Embed the repos first. Everything else depends on pgvector having data.

---

## 16. The Two-Ticket Demo

Create these two tickets in your Jira project before the presentation:

**Ticket A — PROJ-001**
```
Summary: Payment gateway returning 500 errors on retry after timeout
Description: Users are reporting failed payments since 3 AM. The payment 
gateway is returning 500 errors specifically on retry attempts after an 
initial timeout. Error rate is 12% of all payment attempts. 
Affecting production.
Priority: Critical
Labels: payments, production, incident
Component: Backend API
```

**Expected SAGE behaviour:**
- Severity: P0, is_production: true
- Plan: [risk, context, routing] — Explainer skipped
- Risk Agent runs FIRST
- Routes to payments team senior
- Jira comment posted in under 90 seconds

**Ticket B — PROJ-002**
```
Summary: Update API documentation for the new authentication endpoints
Description: The new OAuth2 endpoints added in the last sprint are missing 
from the developer documentation. Need to add examples for /auth/token, 
/auth/refresh, and /auth/revoke endpoints.
Priority: Low
Labels: documentation, auth
Component: Developer Docs
```

**Expected SAGE behaviour:**
- Severity: P2, is_production: false, complexity: low
- Plan: [context, routing, explainer] — Risk Agent skipped
- Explainer generates step-by-step documentation guide
- No risk flags
- Completely different path

**During the presentation:** Show both traces in CompareView. Point to `execution_plan` in each trace. PROJ-001 has `["risk", "context", "routing"]`, PROJ-002 has `["context", "routing", "explainer"]`. This is your proof of agency.

---

## 17. What to Say When a Judge Asks

**"Is this just chaining LLM calls?"**
No. The execution plan is built at runtime by the Orchestrator based on ticket signals. Two tickets take different paths through the graph — visible in the agent trace and LangGraph conditional edges in orchestrator.py. The Context Agent also runs a tool-use loop where it decides whether to retry based on computed confidence scores, not a fixed number of calls.

**"How is the confidence score computed?"**
Mean cosine similarity score from pgvector results — a real number from vector search, not a percentage the LLM invented. Raw similarity scores are visible in the agent trace for each file retrieved.

**"Why Node.js AND FastAPI?"**
Node.js handles auth, Jira polling, and write-back — I/O-bound operations. FastAPI handles LangGraph orchestration and vector search — operations needing Python's ML ecosystem. Separating them lets us scale the AI engine independently.

**"What if the LLM hallucinated a file path?"**
We validate every file path returned by the Context Agent against actual GitHub API responses before writing to scratchpad. Files that don't exist in the repo are rejected.

**"How do you prevent the same ticket from being processed twice?"**
The deduplicator checks the `tickets` table before forwarding. If ticket_key exists with status 'complete' or 'processing', it's dropped.

---

## 18. Requirements Checklist (from PDF)

- [x] Agentic AI system — LangGraph with conditional branching, real tool use, scratchpad
- [x] Agent takes a goal, breaks into steps, decides how to solve, executes with tools
- [x] Clear evidence of reasoning, planning, execution — agent trace in UI
- [x] Not a chatbot wrapper — tool use loop, confidence computation, conditional edges
- [x] Team of 3-4 — assign roles per Section 15
- [x] Prompts accessible through UI — Prompt Studio reads/writes prompts table
- [x] Backend API layer — Node.js gateway + FastAPI AI engine
- [x] Simple user interface — React dashboard
- [x] At least 2 types of testing — pytest (unit) + Postman/Newman (API)
- [x] No hardcoded secrets — all in .env files
- [x] Basic input validation — TicketDTO validation in gateway
- [x] GitHub public repo with regular commits
- [x] Each member commits from own account
- [x] README with setup instructions
- [x] Architecture diagram
- [x] Demo video ≤ 5 minutes
- [x] Docker optional but present — docker-compose.yml included
- [x] Deployment on Azure — GitHub Actions deploys to App Service
- [x] Live link if deployed — Azure App Service URL in README

---

## 19. README Structure

```markdown
# SAGE — Situational Awareness & Guidance Engine

> SAGE is a Jira-integrated multi-agent AI system that builds Situational 
> Briefings for engineering tickets — so junior engineers act immediately 
> instead of waiting, and senior engineers get interrupted less.

## Architecture
[architecture diagram image]

## How It Works
[2 paragraphs: polling → agents → briefing → Jira comment]

## The Two-Ticket Demo
[screenshots of PROJ-001 vs PROJ-002 traces side by side]

## Setup

### Prerequisites
- Jira Cloud account (free tier)
- GitHub account with target repos
- Azure account (free tier)
- Anthropic API key

### Run Locally
\`\`\`bash
cp ai_engine/.env.example ai_engine/.env
cp gateway/.env.example gateway/.env
cp frontend/.env.example frontend/.env
# fill in your values

docker-compose up
# OR run each service separately:
cd ai_engine && uvicorn api.routes:app --reload
cd gateway && npm run dev
cd frontend && npm run dev

# Embed your repos first:
cd ai_engine && python db/embeddings.py
\`\`\`

### Run Tests
\`\`\`bash
pytest ai_engine/tests/ -v
npx newman run ai_engine/tests/sage_api.postman_collection.json
\`\`\`

## Engineering Decisions
[table: decision / alternatives considered / why we chose this]

## Live Demo
[Azure URL]
```

---

## 20. Day Timeline — One Day Left

```
NOW → +2h    Person C: Azure PostgreSQL up + migration run + repos embedded in pgvector
NOW → +2h    Person B: Jira free account + project + 2 demo tickets created + poller running locally
NOW → +2h    Person A: React scaffold + useSSE hook + basic layout

+2h → +5h   Person C: Orchestrator + all 4 agents + synthesis + /analyse + /stream endpoints
+2h → +5h   Person B: jiraWriter + gateway routes + JWT auth + prompt CRUD
+2h → +5h   Person A: AgentTrace + BriefingPanel + ConfidenceBadge

+5h → +8h   ALL: Integration — run PROJ-001 end to end. Fix what breaks.
+5h → +8h   Person A: PromptStudio + CompareView
+5h → +8h   Person B: Push to Azure, GitHub Actions running

+8h → +10h  ALL: Run both demo tickets. Verify different execution paths. Fix reasoning.
+10h → +12h Person A: Polish UI, record demo video
+10h → +12h Person B+C: README + architecture diagram + final commit sweep

Submit before May 2, 11:59 PM IST
```
